
import 'package:flutter/material.dart';

void main() {
  runApp(AviadorBZApp());
}

class AviadorBZApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'aviador_bz',
      home: Scaffold(
        appBar: AppBar(title: Text('Aviador BZ - Bot Automático')),
        body: Center(child: Text('Bot Aviator 100% Automático - Versão Inicial')),
      ),
    );
  }
}
